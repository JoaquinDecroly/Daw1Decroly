public enum tipo {
    INGRESO, RETIRADA
}
